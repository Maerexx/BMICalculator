package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import java.text.DecimalFormat;
import java.util.zip.Inflater;

import static android.content.Intent.ACTION_VIEW;


public class MainActivity extends AppCompatActivity {

    private static final String SHARED_PREFS = "sharedPrefs";
    public static final String TEXT = "weight";
    public static final String TEXT1 = "height";

    EditText edWeg,edHeg;
    TextView txtRes, txtRisk, txtResult;
    Button btnReset, btnResult;

    float bmiValue;
    private String weight, height;
    private Object Menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        edWeg = (EditText) findViewById(R.id.edWeg);
        edHeg= (EditText) findViewById(R.id.edHeg);

        txtResult = (TextView)findViewById(R.id.txtResult);
        txtRisk = (TextView)findViewById(R.id.txtRisk);
        txtRes = (TextView) findViewById(R.id.txtRes);


        btnResult = (Button)findViewById(R.id.btnResult);
        btnReset = (Button)findViewById(R.id.btnReset);

        
        loadData();
        updateViews();

        //sharedPref = this.getSharedPreferences("weight", Context.MODE_PRIVATE);
//        sharedPref = this.getSharedPreferences("height", Context.MODE_PRIVATE);
//        sharedPref = this.getSharedPreferences("result", Context.MODE_PRIVATE);
//        sharedPref = this.getSharedPreferences("risk", Context.MODE_PRIVATE);
//        sharedPref = this.getSharedPreferences("res", Context.MODE_PRIVATE);

        btnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strweg = edWeg.getText().toString();
                String strhei = edHeg.getText().toString();
                if(strweg.equals("")){
                    edWeg.setError("Please Enter Your Weight: ");
                    edWeg.requestFocus();
                    return;
                }
                if (strhei.equals(""))
                {
                    edHeg.setError("Please Enter Your Height");
                    edHeg.requestFocus();
                    return;
                }
                float weight = Float.parseFloat(strweg);
                float height = Float.parseFloat(strhei)/100;

                bmiValue = BMICalculate(weight,height);
                DecimalFormat df = new DecimalFormat("0.00");
                txtRes.setText(interpreteBMI(bmiValue));
                txtRisk.setText(interpreteRisk(bmiValue));
                txtResult.setText("BMI= "+df.format(bmiValue));
                saveData();

            }
        });
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edHeg.setText("");
                edWeg.setText("");
                txtRes.setText("");
                txtRisk.setText("");
                txtResult.setText("");

            }
        });



    }

    private void saveData() {
        SharedPreferences sharedPref = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(TEXT, edWeg.getText().toString());
        editor.putString(TEXT1, edHeg.getText().toString());

        editor.apply();
    }

    private void updateViews() {
        edWeg.setText(weight);
        edHeg.setText(height);
    }

    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        weight = sharedPreferences.getString(TEXT, "");
        height = sharedPreferences.getString(TEXT1, "");
    }

    //private void gotoUrl(String s){
   //     Uri uri = Uri.parse(s);
    //    startActivity(new Intent(ACTION_VIEW, uri));
   // }

    public float BMICalculate(float weight, float height){
        return weight/ (height*height);
    }

    public String interpreteBMI (float bmiValue){
        if(bmiValue<18.5) {
            return "Underweight";
        }
        else if(bmiValue<25) {
            return "Normal Weight";
        }
        else if(bmiValue<30){
            return "Overweight";
        }
        else if(bmiValue<35){
            return "Moderately Obese";
        }
        else if(bmiValue<40){
            return "Severely Obese";
        }
        else
            return "Very severely Obese";
    }
    public String interpreteRisk (float bmiValue){
        if(bmiValue<18.5) {
            return "Malnutrition Risk";
        }
        else if(bmiValue<25) {
            return "Low Risk";
        }
        else if(bmiValue<30){
            return "Enhanced Risk";
        }
        else if(bmiValue<35){
            return "Medium Risk";
        }
        else if(bmiValue<40){
            return "High Risk";
        }
        else
            return "Very High Risk";
    }

    public boolean onCreateOptionsMenu (Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate (R.menu.menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem Item){
        switch(Item.getItemId()) {
            case R.id.about:
                Intent intent = new Intent(this, about.class);
                startActivity(intent);
                break;
            case R.id.bmiCalc:
                Toast.makeText(this, "This is Bmi Calculator", Toast.LENGTH_LONG).show();
                break;
            default:
                return super.onOptionsItemSelected(Item);
        }
        return true;
    }

}